sqlparse_CLI.exe
#
#This program parses an SQLite3 database for deleted entries and
#places the output into either and TSV file, or text file
#
#The SQLite file format, offsets etc is described at
#sqlite.org/fileformat.html
#
#
# Copyright (C) 2014 Mari DeGrazia (arizona4n6@gmail.com)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You can view the GNU General Public License at <http://www.gnu.org/licenses/>
#
# Version History:
# v1.1 2013-11-05
#	
#Find a bug???? Please let me know and I'll try to fix it (if you ask nicely....)
#


For sqlpare_GUI to work, the file sqlparse_CLI.exe must be kept in the same directory.

Usage Examples for sqlparse_CLI.exe:

sqlparse_CLI.exe -f "C:\Users\Mari\smsmms.db" -o "C:\Users\Mari\Reports\output.tsv"

sqlparse_CLI.exe -f "C:\Users\Mari\smsmms.db -r -o "C:\Users\Mari\Reports\output.tsv"
